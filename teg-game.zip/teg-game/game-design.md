# Jogo Educacional — Usina Termoelétrica Interativa
## Design Document & Game Mechanics

---

## PILAR 1: ENGENHARIA DO PERCURSO TECNOLÓGICO

### Fluxo Real da Usina Termoelétrica

```
[1] CALDEIRA (Combustão)
    ├─ Entrada: Combustível (carvão, gás)
    ├─ Processo: Queima gera calor
    └─ Saída: Energia térmica (temperatura em °C)
         ↓
[2] GERADOR DE VAPOR
    ├─ Entrada: Calor da caldeira + Água
    ├─ Processo: Aquecimento da água até evaporação
    └─ Saída: Vapor pressurizado (pressão em bar)
         ↓
[3] TURBINA A VAPOR
    ├─ Entrada: Vapor pressurizado
    ├─ Processo: Expansão do vapor move pás da turbina
    └─ Saída: Rotação mecânica (RPM)
         ↓
[4] GERADOR ELÉTRICO
    ├─ Entrada: Rotação da turbina
    ├─ Processo: Indução eletromagnética (Faraday)
    └─ Saída: Corrente elétrica (MW)
         ↓
[5] CONDENSADOR (Resfriamento)
    ├─ Entrada: Vapor exaurido da turbina
    ├─ Processo: Troca térmica com água de resfriamento
    └─ Saída: Água líquida reciclada → volta à caldeira
```

### Dinâmica do Jogo

**Objetivo Principal**: Manter a usina funcionando com máxima eficiência energética enquanto controla impacto ambiental.

**Variáveis Controláveis**:
- Combustível adicionado (0-100%)
- Abertura da válvula de vapor (0-100%)
- Velocidade do ventilador de resfriamento (0-100%)

**Variáveis Calculadas**:
- Temperatura da caldeira (°C)
- Pressão do vapor (bar)
- Rotação da turbina (RPM)
- Potência gerada (MW)
- Eficiência (%)
- Emissões de CO₂ (kg/h)
- Consumo de água (L/h)

**Desafios**:
1. **Modo Prático**: Manter a usina estável por 5 minutos (tempo real)
2. **Modo Eficiência**: Gerar máxima potência com mínimas emissões
3. **Modo Crise**: Responder a falhas aleatórias (queda de combustível, vazamento, etc.)

---

## PILAR 2: FUNCIONALIDADE ROBUSTA

### Lógica de Simulação

**Equações Simplificadas**:

```javascript
// Temperatura da caldeira (°C)
T_caldeira = 20 + (combustivel_input * 0.8) - (resfriamento * 0.1)

// Pressão do vapor (bar)
P_vapor = 1 + (T_caldeira / 100) * 2

// RPM da turbina
RPM = P_vapor * 500 * (abertura_valvula / 100)

// Potência gerada (MW)
P_MW = (RPM / 3000) * 100

// Eficiência (%)
Eficiencia = (P_MW / (combustivel_input * 0.5)) * 100

// Emissões CO₂ (kg/h)
CO2 = combustivel_input * 2

// Consumo de água (L/h)
H2O = resfriamento * 50
```

### Estados e Transições

- **IDLE**: Usina desligada
- **STARTUP**: Aquecimento inicial (10s)
- **RUNNING**: Operação normal
- **OVERHEAT**: Temperatura > 800°C (alerta vermelho)
- **SHUTDOWN**: Desligamento controlado
- **FAILURE**: Falha crítica (game over)

### Validações

- Impedir valores fora do intervalo [0, 100]
- Detectar instabilidades (mudanças rápidas)
- Avisar antes de atingir limites críticos
- Recuperação automática de pequenas flutuações

---

## PILAR 3: INTERFACE INTUITIVA & USABILIDADE

### Layout Principal

```
┌─────────────────────────────────────────┐
│  TEG POWER PLANT SIMULATOR              │
│  Eficiência: 65% | Potência: 85 MW      │
├─────────────────────────────────────────┤
│                                         │
│  [DIAGRAMA VISUAL DA USINA]             │
│  Caldeira → Turbina → Gerador → Cond.  │
│                                         │
├─────────────────────────────────────────┤
│  CONTROLES:                             │
│  Combustível: [████░░░░░] 60%           │
│  Vapor:       [███░░░░░░] 30%           │
│  Resfriamento:[██░░░░░░░] 20%           │
├─────────────────────────────────────────┤
│  DADOS EM TEMPO REAL:                   │
│  T: 450°C | P: 2.5 bar | RPM: 1250     │
│  CO₂: 120 kg/h | H₂O: 1000 L/h         │
├─────────────────────────────────────────┤
│  [INICIAR] [PARAR] [RESET]              │
└─────────────────────────────────────────┘
```

### Cores & Indicadores

- **Verde**: Operação normal (0-70%)
- **Amarelo**: Alerta (70-85%)
- **Vermelho**: Crítico (>85%)
- **Azul**: Informação (dados técnicos)

---

## PILAR 4: CRIATIVIDADE & IMPACTO

### Sistema de Consequências Ambientais

**Impacto Ambiental Score** (0-100):
- Emissões de CO₂: -0.5 pontos por kg/h
- Consumo de água: -0.2 pontos por 100 L/h
- Eficiência energética: +1 ponto por %

**Feedback Visual**:
- Barra de "Saúde do Planeta" que muda de cor
- Animação de partículas (fumaça) proporcional às emissões
- Mensagens de impacto ("Você economizou 50 kg de CO₂!")

### Desafio de Eficiência

**Ranking de Desempenho**:
1. **Eco Champion** (>80% eficiência, <50 kg CO₂/h)
2. **Efficient Operator** (60-80% eficiência)
3. **Novice Engineer** (40-60% eficiência)
4. **Needs Training** (<40% eficiência)

### Eventos Aleatórios

- **Queda de Combustível**: Redução de 30% na entrada
- **Vazamento de Vapor**: Perda de pressão
- **Falha do Condensador**: Aumento de temperatura
- **Pico de Demanda**: Necessidade de aumentar potência rapidamente

---

## Fluxo de Jogo

1. **Tela Inicial**: Apresentação + Seleção de Modo
2. **Tutorial**: Explicação dos controles (30s)
3. **Simulação**: 5 minutos de gameplay
4. **Resultado**: Score, eficiência, impacto ambiental
5. **Replay**: Opção de tentar novamente ou sair
