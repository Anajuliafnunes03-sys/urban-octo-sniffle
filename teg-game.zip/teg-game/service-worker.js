/**
 * Service Worker para TEG Power Plant Simulator
 * Permite que o app funcione offline e carregue mais rápido
 */

const CACHE_NAME = 'teg-power-plant-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/service-worker.js'
];

/**
 * Evento de instalação
 * Faz cache dos arquivos necessários
 */
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Instalando...');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[Service Worker] Cache aberto');
        return cache.addAll(ASSETS_TO_CACHE);
      })
      .then(() => {
        console.log('[Service Worker] Arquivos em cache');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('[Service Worker] Erro ao instalar:', error);
      })
  );
});

/**
 * Evento de ativação
 * Remove caches antigos
 */
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Ativando...');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== CACHE_NAME) {
              console.log('[Service Worker] Removendo cache antigo:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[Service Worker] Pronto para controlar clientes');
        return self.clients.claim();
      })
  );
});

/**
 * Evento de fetch
 * Estratégia: Cache first, network fallback
 * Se estiver offline, usa o cache; se online, tenta rede
 */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  
  // Ignorar requisições não-GET
  if (request.method !== 'GET') {
    return;
  }
  
  event.respondWith(
    caches.match(request)
      .then((response) => {
        // Se encontrou no cache, retorna
        if (response) {
          console.log('[Service Worker] Retornando do cache:', request.url);
          return response;
        }
        
        // Se não encontrou no cache, tenta rede
        return fetch(request)
          .then((response) => {
            // Se a resposta não é válida, retorna erro
            if (!response || response.status !== 200 || response.type === 'error') {
              return response;
            }
            
            // Faz uma cópia da resposta para armazenar no cache
            const responseToCache = response.clone();
            
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(request, responseToCache);
              });
            
            return response;
          })
          .catch(() => {
            // Se offline e não tem no cache, retorna página offline
            console.log('[Service Worker] Offline:', request.url);
            
            // Para requisições de HTML, retorna a página principal
            if (request.headers.get('accept').includes('text/html')) {
              return caches.match('/index.html');
            }
            
            // Para outros tipos, retorna erro genérico
            return new Response('Offline - recurso não disponível', {
              status: 503,
              statusText: 'Service Unavailable',
              headers: new Headers({
                'Content-Type': 'text/plain'
              })
            });
          });
      })
  );
});

/**
 * Evento de mensagem
 * Permite comunicação com a página principal
 */
self.addEventListener('message', (event) => {
  console.log('[Service Worker] Mensagem recebida:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/**
 * Sincronização em background
 * Permite salvar dados quando voltar online
 */
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-scores') {
    event.waitUntil(
      // Aqui você poderia enviar pontuações para um servidor
      Promise.resolve()
    );
  }
});

/**
 * Notificações push
 * Para futuras expansões do app
 */
self.addEventListener('push', (event) => {
  const options = {
    body: event.data ? event.data.text() : 'Nova mensagem',
    icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192"><defs><linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:%23ff6b35;stop-opacity:1" /><stop offset="100%" style="stop-color:%23ffa500;stop-opacity:1" /></linearGradient></defs><rect fill="url(%23grad)" width="192" height="192" rx="45"/><text x="96" y="96" font-size="100" fill="white" text-anchor="middle" dominant-baseline="middle" font-weight="bold">⚡</text></svg>',
    badge: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect fill="%23ff6b35" width="96" height="96" rx="22"/><text x="48" y="48" font-size="50" fill="white" text-anchor="middle" dominant-baseline="middle">⚡</text></svg>',
    tag: 'teg-notification',
    requireInteraction: false
  };
  
  event.waitUntil(
    self.registration.showNotification('TEG Power Plant', options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window' })
      .then((clientList) => {
        // Se a janela já está aberta, foca nela
        for (let client of clientList) {
          if (client.url === '/' && 'focus' in client) {
            return client.focus();
          }
        }
        // Se não está aberta, abre uma nova
        if (clients.openWindow) {
          return clients.openWindow('/');
        }
      })
  );
});
