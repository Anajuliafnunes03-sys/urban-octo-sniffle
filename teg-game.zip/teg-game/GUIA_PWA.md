# 📱 Guia Completo: PWA (Progressive Web App)

## O que foi implementado?

O TEG Power Plant Simulator agora é um **Progressive Web App (PWA)** completo com:

### ✅ Recursos Implementados

1. **Web App Manifest** (`manifest.json`)
   - Metadados do app (nome, descrição, ícones)
   - Configuração de display (standalone/fullscreen)
   - Atalhos de teclado
   - Tema de cores

2. **Service Worker** (`service-worker.js`)
   - Cache inteligente (offline-first)
   - Sincronização em background
   - Notificações push
   - Atualização automática

3. **Meta Tags Apple** (no `index.html`)
   - `apple-mobile-web-app-capable`: Permite instalação
   - `apple-mobile-web-app-status-bar-style`: Estilo da barra
   - `apple-mobile-web-app-title`: Nome do app
   - `apple-touch-icon`: Ícone da tela inicial

4. **Otimizações**
   - Viewport com `viewport-fit=cover` (notch support)
   - Safe area insets para Dynamic Island
   - Prevenção de zoom duplo
   - Suporte a orientação

---

## Arquivos do PWA

```
teg-game/
├── index.html              ← App principal (com meta tags PWA)
├── manifest.json           ← Configuração do app
├── service-worker.js       ← Cache e offline
├── .htaccess               ← Configuração Apache
├── nginx.conf              ← Configuração Nginx
├── INSTALACAO_IPHONE.md    ← Guia de instalação
└── GUIA_PWA.md            ← Este arquivo
```

---

## Como Funciona?

### 1. Primeira Visita
```
Usuário abre a URL no Safari
    ↓
Navegador detecta manifest.json
    ↓
Service Worker é registrado
    ↓
Arquivos são colocados em cache
    ↓
App está pronto para usar
```

### 2. Instalação na Tela Inicial
```
Usuário toca em Compartilhar
    ↓
Seleciona "Adicionar à Tela Inicial"
    ↓
Ícone aparece com nome "TEG Power"
    ↓
Toque abre o app em tela cheia
```

### 3. Funcionamento Offline
```
Service Worker intercepta requisições
    ↓
Se online: busca na rede
    ↓
Se offline: retorna do cache
    ↓
App funciona normalmente
```

### 4. Atualização
```
Service Worker verifica atualizações a cada hora
    ↓
Se nova versão disponível: notifica usuário
    ↓
Usuário recarrega
    ↓
Nova versão é instalada
```

---

## Estratégia de Cache

### Cache-First (Padrão)
```javascript
// Tenta cache primeiro, depois rede
1. Procura no cache
2. Se encontrou: retorna
3. Se não encontrou: busca na rede
4. Armazena na rede
```

**Arquivos em cache**:
- `index.html`
- `manifest.json`
- `service-worker.js`

### Network-First (Futuro)
Para APIs:
```javascript
// Tenta rede primeiro, depois cache
1. Tenta buscar na rede
2. Se falhar: usa cache
3. Se não tem cache: erro
```

---

## Configuração do Servidor

### Apache (.htaccess)

O arquivo `.htaccess` já está configurado com:

```apache
# Reescrever URLs (SPA)
RewriteRule ^ index.html [QSA,L]

# Cache do Service Worker (sem cache)
Header set Cache-Control "public, max-age=0, must-revalidate"

# Cache de arquivos estáticos (1 ano)
Header set Cache-Control "public, max-age=31536000, immutable"

# Headers de segurança
Header set X-Frame-Options "SAMEORIGIN"
Header set Content-Security-Policy "..."
```

### Nginx (nginx.conf)

O arquivo `nginx.conf` já está configurado com:

```nginx
# Reescrever URLs (SPA)
try_files $uri $uri/ /index.html;

# Service Worker sem cache
add_header Cache-Control "public, max-age=0, must-revalidate";

# Compressão Gzip
gzip on;
gzip_types text/plain text/css text/javascript ...;

# Headers de segurança
add_header X-Frame-Options "SAMEORIGIN";
add_header Content-Security-Policy "...";
```

---

## Hospedagem

### Opção 1: Vercel (Recomendado para PWA)
```bash
npm install -g vercel
vercel
```
- Deploy automático
- HTTPS por padrão
- CDN global
- Suporte PWA nativo

### Opção 2: Netlify
```bash
npm install -g netlify-cli
netlify deploy --prod --dir .
```
- Deploy simples
- HTTPS por padrão
- Redirects automáticos
- Suporte PWA

### Opção 3: GitHub Pages
```bash
git push origin main
```
- Gratuito
- HTTPS por padrão
- Requer configuração extra para PWA

### Opção 4: Servidor Próprio
```bash
# Copiar arquivos para servidor
scp -r teg-game/* usuario@seu-servidor:/var/www/teg-power-plant/

# Configurar Nginx
sudo cp nginx.conf /etc/nginx/sites-available/teg-power-plant
sudo ln -s /etc/nginx/sites-available/teg-power-plant /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Certificado SSL (Let's Encrypt)
sudo certbot certonly --nginx -d seu-dominio.com
```

---

## Testando o PWA

### 1. Verificar Manifest
```javascript
// No console do navegador
navigator.serviceWorker.getRegistrations()
    .then(registrations => console.log(registrations));
```

### 2. Verificar Cache
```javascript
// No console
caches.keys().then(names => console.log(names));
caches.open('teg-power-plant-v1').then(cache => cache.keys().then(keys => console.log(keys)));
```

### 3. Testar Offline
1. Abra DevTools (F12)
2. Vá para Application → Service Workers
3. Marque "Offline"
4. Recarregue a página
5. App deve funcionar normalmente

### 4. Lighthouse Audit
1. Abra DevTools (F12)
2. Vá para Lighthouse
3. Clique em "Analyze page load"
4. Verifique score de PWA

---

## Recursos Avançados

### Notificações Push
```javascript
// Solicitar permissão
Notification.requestPermission().then(permission => {
    if (permission === 'granted') {
        new Notification('TEG Power', {
            body: 'Bem-vindo ao simulador!',
            icon: 'icon.svg'
        });
    }
});
```

### Sincronização em Background
```javascript
// Registrar sincronização
navigator.serviceWorker.ready.then(registration => {
    registration.sync.register('sync-scores');
});

// No Service Worker
self.addEventListener('sync', event => {
    if (event.tag === 'sync-scores') {
        event.waitUntil(syncScores());
    }
});
```

### Compartilhamento de Dados
```javascript
// Usar Share API
if (navigator.share) {
    navigator.share({
        title: 'TEG Power Plant',
        text: 'Confira minha pontuação!',
        url: window.location.href
    });
}
```

### Acesso a Câmera/Localização
```javascript
// Câmera
navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => { /* usar stream */ });

// Localização
navigator.geolocation.getCurrentPosition(position => {
    console.log(position.coords);
});
```

---

## Segurança

### HTTPS Obrigatório
- PWA requer HTTPS (exceto localhost)
- Use Let's Encrypt (gratuito)
- Renovação automática

### Content Security Policy
```
default-src 'self'              ← Apenas recursos locais
script-src 'self' 'unsafe-inline' ← Scripts locais e inline
style-src 'self' 'unsafe-inline'  ← Estilos locais e inline
img-src 'self' data:             ← Imagens locais e data URIs
```

### Headers de Segurança
```
X-Frame-Options: SAMEORIGIN          ← Previne clickjacking
X-Content-Type-Options: nosniff      ← Previne MIME sniffing
X-XSS-Protection: 1; mode=block      ← Previne XSS
Referrer-Policy: strict-origin       ← Controla referrer
```

---

## Performance

### Métricas Importantes

| Métrica | Alvo | Como Medir |
|---------|------|-----------|
| First Contentful Paint (FCP) | < 1.8s | Lighthouse |
| Largest Contentful Paint (LCP) | < 2.5s | Lighthouse |
| Cumulative Layout Shift (CLS) | < 0.1 | Lighthouse |
| Time to Interactive (TTI) | < 3.8s | Lighthouse |

### Otimizações Aplicadas
- ✅ Compressão Gzip
- ✅ Cache inteligente
- ✅ Arquivo único (sem split)
- ✅ Minificação de CSS/JS
- ✅ Ícones em SVG (escaláveis)

---

## Troubleshooting

### Service Worker não registra
```javascript
// Verificar erros
navigator.serviceWorker.register('service-worker.js')
    .catch(error => console.error('Erro:', error));
```

**Soluções**:
- Verificar se HTTPS está ativado
- Verificar se arquivo existe
- Limpar cache do navegador

### App não funciona offline
- Abrir app com internet uma vez
- Service Worker precisa cachear recursos
- Verificar console para erros

### Ícone não aparece
- Verificar se `manifest.json` está correto
- Verificar se `apple-touch-icon` está no HTML
- Limpar cache do Safari

### Notificações não funcionam
- Solicitar permissão do usuário
- Verificar se Service Worker está ativo
- Testar em HTTPS

---

## Próximos Passos

### Melhorias Futuras
1. **Sincronização de Pontuações**
   - Salvar scores na nuvem
   - Sincronizar entre dispositivos

2. **Notificações Push**
   - Avisar sobre novas versões
   - Lembretes de jogar

3. **Modo Multiplayer**
   - Competir com amigos
   - Leaderboard global

4. **Integração com Redes Sociais**
   - Compartilhar resultados
   - Desafios entre amigos

5. **Análise de Dados**
   - Rastrear progresso
   - Estatísticas de jogo

---

## Recursos Úteis

- [MDN: Progressive Web Apps](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)
- [Google: Web.dev PWA](https://web.dev/progressive-web-apps/)
- [Apple: Configuring Web Applications](https://developer.apple.com/library/archive/documentation/AppleApplications/Reference/SafariWebContent/ConfiguringWebApplications/ConfiguringWebApplications.html)
- [W3C: Web App Manifest](https://www.w3.org/TR/appmanifest/)
- [MDN: Service Workers](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API)

---

## Suporte

Se encontrar problemas:

1. Verifique o console (F12)
2. Limpe cache e cookies
3. Reinstale o app
4. Atualize o iOS
5. Entre em contato com suporte

---

**Aproveite seu PWA! 🚀📱**
