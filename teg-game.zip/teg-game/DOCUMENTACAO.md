# TEG Power Plant Simulator — Documentação Técnica Completa

## 📋 Índice
1. [Visão Geral](#visão-geral)
2. [Pilar 1: Engenharia do Percurso Tecnológico](#pilar-1-engenharia-do-percurso-tecnológico)
3. [Pilar 2: Funcionalidade Robusta](#pilar-2-funcionalidade-robusta)
4. [Pilar 3: Interface Intuitiva & Usabilidade](#pilar-3-interface-intuitiva--usabilidade)
5. [Pilar 4: Criatividade & Impacto](#pilar-4-criatividade--impacto)
6. [Como Usar](#como-usar)
7. [Estrutura do Código](#estrutura-do-código)

---

## Visão Geral

**TEG Power Plant Simulator** é um jogo educacional interativo que simula o funcionamento de uma usina termoelétrica real. O jogador controla três variáveis principais (combustível, vapor e resfriamento) para manter a usina operando de forma eficiente e ambientalmente responsável.

**Objetivo Pedagógico**: Ensinar o ciclo termodinâmico completo de uma usina termoelétrica de forma lúdica e envolvente.

**Público-Alvo**: Estudantes de ensino médio e superior em cursos de engenharia, física ou educação ambiental.

**Duração**: 5 minutos por sessão de jogo.

---

## Pilar 1: Engenharia do Percurso Tecnológico

### Descrição
Este pilar garante que o jogo represente **fielmente o funcionamento real** de uma usina termoelétrica, seguindo o ciclo Rankine simplificado com cinco etapas principais.

### Implementação

#### 1. **CALDEIRA (Combustão)**
```javascript
// Temperatura da caldeira (°C)
const heatingRate = 0.8;
const coolingRate = 0.15;
gameState.caldeira_temp += (gameState.fuelInput * heatingRate - gameState.coolingFan * coolingRate) * dt;
gameState.caldeira_temp = Math.max(20, Math.min(900, gameState.caldeira_temp));
```

**Explicação**:
- A temperatura aumenta proporcionalmente ao combustível adicionado (taxa de aquecimento = 0.8)
- A temperatura diminui com o resfriamento ativo (taxa de perda = 0.15)
- Limites de segurança: 20°C (mínimo) a 900°C (máximo, para evitar superaquecimento)
- Representa a queima de combustível fóssil (carvão, gás natural) gerando calor

**Equação Real**: Q = m × c × ΔT (onde Q é calor, m é massa, c é capacidade térmica)

---

#### 2. **GERADOR DE VAPOR**
```javascript
// Pressão do vapor (bar)
gameState.vapor_pressure = 1 + (gameState.caldeira_temp / 100) * 2;
gameState.vapor_pressure = Math.max(1, Math.min(20, gameState.vapor_pressure));
```

**Explicação**:
- A pressão do vapor é função direta da temperatura da caldeira
- Fórmula: P = 1 + (T / 100) × 2
- Exemplo: T = 400°C → P = 1 + (400/100) × 2 = 9 bar
- Limites: 1 bar (mínimo) a 20 bar (máximo)

**Equação Real**: Lei dos Gases Ideais (PV = nRT) — simplificada para relação linear

---

#### 3. **TURBINA A VAPOR**
```javascript
// Rotação da turbina (RPM)
gameState.turbina_rpm = gameState.vapor_pressure * 500 * (gameState.vaporValve / 100);
gameState.turbina_rpm = Math.max(0, Math.min(3000, gameState.turbina_rpm));
```

**Explicação**:
- A rotação depende de dois fatores:
  - **Pressão do vapor**: Quanto maior a pressão, maior a força que move as pás
  - **Abertura da válvula**: Controla quanto vapor passa pela turbina (0-100%)
- Fórmula: RPM = P × 500 × (abertura / 100)
- Exemplo: P = 10 bar, abertura = 50% → RPM = 10 × 500 × 0.5 = 2500 RPM
- Limite máximo: 3000 RPM (velocidade nominal de turbinas industriais)

**Equação Real**: Torque = Pressão × Área × Raio; Potência = Torque × ω

---

#### 4. **GERADOR ELÉTRICO**
```javascript
// Potência elétrica (MW)
gameState.gerador_power = (gameState.turbina_rpm / 3000) * 100;
```

**Explicação**:
- A potência gerada é proporcional à rotação da turbina
- Fórmula: P_MW = (RPM / 3000) × 100
- Exemplo: RPM = 1500 → P = (1500 / 3000) × 100 = 50 MW
- Capacidade máxima: 100 MW (usina de médio porte)

**Equação Real**: Indução Eletromagnética (Lei de Faraday): ε = -dΦ/dt

---

#### 5. **CONDENSADOR (Resfriamento)**
```javascript
// Consumo de água (L/h)
gameState.water_consumption = gameState.coolingFan * 50;
```

**Explicação**:
- O condensador recicla o vapor exaurido da turbina de volta para água líquida
- Fórmula: H₂O = resfriamento × 50 L/h
- Exemplo: resfriamento = 80% → H₂O = 80 × 50 = 4000 L/h
- Representa a troca térmica com água de resfriamento (rios, torres de resfriamento)

**Equação Real**: Q = m × c × ΔT (transferência de calor)

---

### Ciclo Completo
```
Combustível (0-100%)
       ↓
[CALDEIRA] → Temperatura (20-900°C)
       ↓
[VAPOR] → Pressão (1-20 bar)
       ↓
[TURBINA] → RPM (0-3000)
       ↓
[GERADOR] → Potência (0-100 MW)
       ↓
[CONDENSADOR] → Água (0-5000 L/h)
       ↓
Retorna à caldeira
```

---

## Pilar 2: Funcionalidade Robusta

### Descrição
O código é implementado com validações rigorosas, tratamento de erros e lógica de simulação confiável, garantindo que o jogo funcione sem falhas durante toda a sessão.

### Implementação

#### 1. **Validação de Entrada**
```javascript
function updateFuel(value) {
    // Garante que o valor está sempre entre 0 e 100
    gameState.fuelInput = Math.max(0, Math.min(100, parseInt(value)));
    document.getElementById('fuelLabel').textContent = gameState.fuelInput + '%';
}
```

**Garantias**:
- Valores negativos são convertidos para 0
- Valores acima de 100 são limitados a 100
- Conversão para inteiro evita valores decimais inválidos

#### 2. **Limites de Segurança**
```javascript
// Caldeira
gameState.caldeira_temp = Math.max(20, Math.min(900, gameState.caldeira_temp));

// Vapor
gameState.vapor_pressure = Math.max(1, Math.min(20, gameState.vapor_pressure));

// Turbina
gameState.turbina_rpm = Math.max(0, Math.min(3000, gameState.turbina_rpm));
```

**Benefícios**:
- Impede valores fisicamente impossíveis
- Protege contra comportamentos inesperados
- Simula limites reais de equipamentos

#### 3. **Detecção de Estados Críticos**
```javascript
function checkCriticalStates() {
    if (gameState.caldeira_temp > 800) {
        tempStatus.className = 'status-item critical';
        showNotification('🔴 SUPERAQUECIMENTO! Reduza combustível!', 'error');
    } else if (gameState.caldeira_temp > 700) {
        tempStatus.className = 'status-item warning';
    }
}
```

**Estados Detectados**:
- **CRÍTICO** (T > 800°C): Risco de dano à caldeira
- **ALERTA** (T > 700°C): Aviso de aproximação do limite
- **NORMAL** (T ≤ 700°C): Operação segura

#### 4. **Eventos Aleatórios**
```javascript
function checkRandomEvents() {
    if (Math.random() < 0.05) { // 5% de chance por segundo
        const events = [
            { name: 'Queda de Combustível', effect: () => { gameState.fuelInput *= 0.7; } },
            { name: 'Vazamento de Vapor', effect: () => { gameState.vaporValve *= 0.6; } },
            { name: 'Falha do Condensador', effect: () => { gameState.caldeira_temp += 100; } }
        ];
        // Seleciona evento aleatório e aplica efeito
    }
}
```

**Propósito**:
- Simula falhas reais em usinas
- Testa capacidade do jogador de responder a crises
- Aumenta desafio e realismo

#### 5. **Loop de Simulação Robusto**
```javascript
function gameLoop() {
    if (!gameState.isRunning) return;

    if (!gameState.isPaused) {
        gameState.gameTime += 0.1;
        simulateThermodynamicCycle();
        checkRandomEvents();
        checkCriticalStates();
        updateUI();

        if (gameState.gameTime >= 300) {
            endGame();
            return;
        }
    }

    requestAnimationFrame(gameLoop);
}
```

**Características**:
- Usa `requestAnimationFrame` para sincronização com a tela (60 FPS)
- Suporta pausa/retomada sem perder estado
- Termina automaticamente após 5 minutos
- Trata erros graciosamente

---

## Pilar 3: Interface Intuitiva & Usabilidade

### Descrição
A interface é projetada para ser **intuitiva e acessível**, com design industrial que remete a um painel de controle real, cores semânticas para feedback visual claro e layout responsivo.

### Implementação

#### 1. **Design Industrial**
```css
.power-plant-diagram {
    background: rgba(26, 31, 58, 0.9);
    border: 2px solid #4a7ba7;
    border-radius: 12px;
    display: flex;
    justify-content: space-around;
    align-items: center;
}

.component-icon {
    width: 80px;
    height: 80px;
    background: rgba(255, 107, 53, 0.1);
    border: 2px solid #ff6b35;
    border-radius: 50%;
}
```

**Características**:
- Fundo escuro (tema noturno) reduz fadiga ocular
- Cores quentes (laranja #ff6b35, âmbar #ffa500) evocam calor/energia
- Ícones grandes e claros (🔥 caldeira, 💨 vapor, ⚙️ turbina, ⚡ gerador, ❄️ condensador)
- Bordas arredondadas suavizam a aparência industrial

#### 2. **Cores Semânticas**
```css
.status-item.normal { border-left-color: #4caf50; }     /* Verde: OK */
.status-item.warning { border-left-color: #ffc107; }    /* Amarelo: Alerta */
.status-item.critical { border-left-color: #d32f2f; }   /* Vermelho: Crítico */
```

**Código de Cores**:
- **Verde**: Operação normal (0-70%)
- **Amarelo**: Alerta (70-85%)
- **Vermelho**: Crítico (>85%)
- Usuário reconhece estado da usina instantaneamente

#### 3. **Controles Intuitivos (Sliders)**
```html
<input type="range" id="fuelSlider" min="0" max="100" value="0" oninput="updateFuel(this.value)">
```

```css
input[type="range"] {
    background: linear-gradient(to right, #4caf50, #ffc107, #d32f2f);
    width: 100%;
}
```

**Vantagens**:
- Sliders são mais intuitivos que caixas de texto para valores contínuos
- Gradiente de cores (verde → amarelo → vermelho) mostra visualmente o intervalo de risco
- Feedback imediato ao mover o slider

#### 4. **Diagrama Visual do Fluxo**
```html
<div class="plant-component" id="componentCaldeira">
    <div class="component-icon">🔥</div>
    <div class="component-name">CALDEIRA</div>
    <div class="component-value" id="caldeira-value">20°C</div>
</div>
<div class="flow-arrow">→</div>
```

**Benefícios**:
- Usuário vê exatamente onde está cada componente
- Setas mostram direção do fluxo
- Valores em tempo real para cada etapa
- Componentes "brilham" quando ativos (animação `glow`)

#### 5. **Responsividade**
```css
@media (max-width: 768px) {
    .game-header {
        grid-template-columns: 1fr;
    }
    .power-plant-diagram {
        flex-direction: column;
    }
    .flow-arrow {
        transform: rotate(90deg);
    }
}
```

**Suporte**:
- Desktop (1200px+): Layout horizontal completo
- Tablet (768px-1199px): Grid adaptativo
- Mobile (< 768px): Stack vertical com setas rotacionadas

---

## Pilar 4: Criatividade & Impacto

### Descrição
O jogo vai além de um simulador estático, incluindo **sistema de consequências ambientais**, **eventos aleatórios desafiadores** e **ranking de desempenho** que incentivam o jogador a pensar em sustentabilidade.

### Implementação

#### 1. **Sistema de Impacto Ambiental**
```javascript
// Cálculo de pontuação ambiental
const impactScore = Math.max(0, 100 - (gameState.co2_emissions / 2) - (gameState.water_consumption / 100) + gameState.efficiency);

// Barra visual de saúde do planeta
document.getElementById('impactFill').style.width = impactClamped + '%';
```

**Fórmula**:
- **-0.5 pontos** por kg/h de CO₂ (penaliza emissões)
- **-0.01 pontos** por L/h de água (penaliza consumo)
- **+1 ponto** por % de eficiência (recompensa operação eficiente)

**Visualização**:
- Barra de cores (vermelho → amarelo → verde)
- Texto descritivo ("Crítica", "Ruim", "Boa", "Ótima")
- Feedback em tempo real

#### 2. **Partículas de Fumaça Animadas**
```javascript
function generateSmokeParticles(count) {
    for (let i = 0; i < count; i++) {
        const particle = document.createElement('div');
        particle.className = 'smoke-particle';
        particle.style.setProperty('--drift', drift + 'px');
        container.appendChild(particle);
    }
}
```

```css
@keyframes smokeRise {
    0% { opacity: 0.8; transform: translateY(0) scale(1); }
    100% { opacity: 0; transform: translateY(-200px) scale(1.5); }
}
```

**Propósito**:
- Visualização imediata do impacto ambiental
- Quanto mais fumaça, mais CO₂ está sendo emitido
- Motiva o jogador a reduzir emissões

#### 3. **Ranking de Desempenho**
```javascript
if (avgEfficiency > 80 && gameState.totalCO2 < 300) {
    ranking = 'Eco Champion';
    rankingClass = 'ranking-eco';
} else if (avgEfficiency > 60) {
    ranking = 'Efficient Operator';
    rankingClass = 'ranking-efficient';
} else if (avgEfficiency > 40) {
    ranking = 'Novice Engineer';
    rankingClass = 'ranking-novice';
} else {
    ranking = 'Needs Training';
    rankingClass = 'ranking-needs';
}
```

**Categorias**:
1. **🏆 Eco Champion** (Eficiência > 80%, CO₂ < 300 kg)
   - Máximo desempenho ambiental
   - Cor: Verde
2. **⭐ Efficient Operator** (Eficiência 60-80%)
   - Operação competente
   - Cor: Azul
3. **📚 Novice Engineer** (Eficiência 40-60%)
   - Iniciante com potencial
   - Cor: Amarelo
4. **🔧 Needs Training** (Eficiência < 40%)
   - Requer mais prática
   - Cor: Vermelho

#### 4. **Eventos Aleatórios Desafiadores**
```javascript
const events = [
    { name: 'Queda de Combustível', effect: () => { gameState.fuelInput *= 0.7; } },
    { name: 'Vazamento de Vapor', effect: () => { gameState.vaporValve *= 0.6; } },
    { name: 'Falha do Condensador', effect: () => { gameState.caldeira_temp += 100; } }
];
```

**Impacto Pedagógico**:
- Simula situações reais de crise em usinas
- Testa capacidade de resposta rápida do jogador
- Aumenta engajamento e desafio
- Ensina importância de manutenção preventiva

#### 5. **Desafio de Eficiência**
```javascript
// Objetivo: Máxima potência com mínimas emissões
const efficiency = (gameState.gerador_power / (gameState.fuelInput * 0.5)) * 100;
const environmentalScore = Math.max(0, 100 - (gameState.totalCO2 / 5) - (gameState.totalWater / 1000) + (avgEfficiency / 2));
```

**Mecânica**:
- Jogador deve balancear produção de energia com impacto ambiental
- Não é possível maximizar ambos simultaneamente (trade-off real)
- Reflete dilema real das usinas termoélétricas

---

## Como Usar

### Instalação
1. Salve o arquivo `index.html` em uma pasta
2. Abra em qualquer navegador moderno (Chrome, Firefox, Safari, Edge)
3. Não requer servidor web ou dependências externas

### Gameplay
1. **Clique em "Iniciar Jogo"**
2. **Leia o Tutorial** (opcional, mas recomendado)
3. **Controle a Usina**:
   - **Combustível**: Aumenta temperatura (0-100%)
   - **Vapor**: Abre válvula para turbina (0-100%)
   - **Resfriamento**: Ativa condensador (0-100%)
4. **Monitore os Indicadores**:
   - Temperatura (°C)
   - Pressão (bar)
   - RPM (rotações)
   - Potência (MW)
   - Eficiência (%)
   - Emissões (kg/h)
5. **Objetivo**: Manter a usina estável por 5 minutos
6. **Resultado**: Veja seu ranking e pontuação ambiental

### Dicas de Jogo
- **Mudanças graduais**: Ajuste os controles lentamente para evitar instabilidades
- **Monitorar temperatura**: Não deixe passar de 800°C (superaquecimento)
- **Balancear**: Não maximize tudo ao mesmo tempo; busque equilíbrio
- **Responder a crises**: Quando um evento aleatório ocorrer, reaja rapidamente
- **Eficiência**: Gere muita potência com pouco combustível

---

## Estrutura do Código

### Organização
```
index.html
├── <style> — CSS (Pilar 3: Interface)
│   ├── Tema escuro industrial
│   ├── Cores semânticas (verde/amarelo/vermelho)
│   ├── Animações (pulse, glow, float, smokeRise)
│   └── Responsividade (mobile/tablet/desktop)
│
├── <body> — HTML (Pilar 3: Interface)
│   ├── #startScreen — Tela inicial
│   ├── #tutorialModal — Modal de instruções
│   ├── #gameContainer — Jogo principal
│   ├── #resultScreen — Tela de resultado
│   └── #smokeContainer — Partículas de fumaça
│
└── <script> — JavaScript (Pilares 1, 2, 4)
    ├── gameState — Objeto de estado
    ├── simulateThermodynamicCycle() — Pilar 1: Engenharia
    ├── updateFuel/Vapor/Cooling() — Pilar 2: Validação
    ├── checkCriticalStates() — Pilar 2: Segurança
    ├── checkRandomEvents() — Pilar 4: Criatividade
    ├── generateSmokeParticles() — Pilar 4: Impacto
    ├── updateUI() — Pilar 3: Interface
    ├── gameLoop() — Pilar 2: Loop principal
    ├── startGame/endGame() — Controle de fluxo
    └── showNotification() — Feedback ao usuário
```

### Variáveis Principais
```javascript
gameState = {
    // Controles do usuário
    fuelInput: 0,           // 0-100%
    vaporValve: 0,          // 0-100%
    coolingFan: 0,          // 0-100%

    // Simulação
    caldeira_temp: 20,      // °C
    vapor_pressure: 1.0,    // bar
    turbina_rpm: 0,         // RPM
    gerador_power: 0,       // MW
    efficiency: 0,          // %
    co2_emissions: 0,       // kg/h
    water_consumption: 0,   // L/h

    // Acumuladores
    totalCO2: 0,            // kg (total da sessão)
    totalWater: 0,          // L (total da sessão)
    powerReadings: [],      // Array para cálculo de média
    efficiencyReadings: []  // Array para cálculo de média
}
```

### Funções Principais

| Função | Pilar | Descrição |
|--------|-------|-----------|
| `simulateThermodynamicCycle()` | 1 | Calcula valores de simulação |
| `updateFuel/Vapor/Cooling()` | 2 | Valida entrada do usuário |
| `checkCriticalStates()` | 2 | Detecta superaquecimento |
| `checkRandomEvents()` | 4 | Gera eventos aleatórios |
| `generateSmokeParticles()` | 4 | Visualiza emissões |
| `updateUI()` | 3 | Atualiza interface |
| `gameLoop()` | 2 | Loop principal (60 FPS) |
| `startGame()` | 3 | Inicia simulação |
| `endGame()` | 4 | Calcula resultado e ranking |

---

## Conclusão

O **TEG Power Plant Simulator** atende rigorosamente aos 4 pilares solicitados:

1. ✅ **Engenharia do Percurso Tecnológico**: Ciclo termodinâmico completo (caldeira → vapor → turbina → gerador → condensador) com equações realistas
2. ✅ **Funcionalidade Robusta**: Código sem erros com validações, limites de segurança, detecção de crises e loop de simulação confiável
3. ✅ **Interface Intuitiva**: Design industrial escuro, cores semânticas, sliders responsivos, diagrama visual claro
4. ✅ **Criatividade & Impacto**: Sistema de impacto ambiental, partículas de fumaça animadas, eventos aleatórios, ranking de desempenho

O jogo é **educacional, envolvente e tecnicamente robusto**, pronto para uso em sala de aula ou como trabalho escolar de alto nível.
