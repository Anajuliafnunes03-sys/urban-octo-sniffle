# 📱 Como Instalar o TEG Power Plant Simulator no iPhone

## O que é um Progressive Web App (PWA)?

Um **PWA** é um aplicativo web que funciona como um app nativo no seu iPhone. Ele:
- ✅ Funciona offline (sem internet)
- ✅ Carrega mais rápido (cache inteligente)
- ✅ Aparece na tela inicial como um app normal
- ✅ Funciona em tela cheia (sem barra de navegador)
- ✅ Recebe notificações push (futuro)

## Pré-requisitos

- iPhone com iOS 11.3 ou superior
- Safari (navegador padrão do iPhone)
- Conexão com internet (para primeira instalação)

## Método 1: Instalação via Safari (Recomendado)

### Passo 1: Abrir o App no Safari
1. Abra o **Safari** no seu iPhone
2. Acesse a URL do jogo (você receberá um link)
3. Aguarde o app carregar completamente

### Passo 2: Adicionar à Tela Inicial
1. Toque no **ícone de Compartilhamento** (caixa com seta para cima)
   - Localizado na barra inferior do Safari
   
2. Role para baixo e toque em **"Adicionar à Tela Inicial"**
   
3. Você verá uma prévia do app com:
   - Nome: "TEG Power" (pode ser editado)
   - Ícone: Símbolo de raio laranja ⚡
   
4. Toque em **"Adicionar"** no canto superior direito

### Passo 3: Pronto! 🎉
- O app agora aparece na sua tela inicial
- Toque no ícone para abrir
- Funciona como um app normal!

## Método 2: Instalação via Link Compartilhado

Se receber um link por mensagem/email:

1. Toque no link
2. Safari abrirá automaticamente
3. Siga os passos do Método 1 (a partir do Passo 2)

## Usando o App

### Primeira Vez
- O app pode levar alguns segundos para carregar (normal)
- Service Worker será instalado automaticamente
- Próximas aberturas serão instantâneas

### Modo Offline
- Após a primeira abertura, o app funciona **sem internet**
- Todos os dados são salvos localmente
- Suas pontuações são armazenadas no dispositivo

### Atualizações
- O app verifica atualizações a cada hora
- Se houver nova versão, você receberá uma notificação
- Recarregue o app para usar a versão mais recente

## Recursos Especiais do iPhone

### Notch / Dynamic Island
- O app se adapta automaticamente
- Não há conteúdo sob o notch

### Orientação
- Funciona em **retrato** (vertical)
- Otimizado para essa orientação

### Gesto de Retorno
- Deslize da borda esquerda para voltar (se disponível)

## Solução de Problemas

### O app não abre
**Solução**: 
- Feche o Safari completamente
- Toque no ícone novamente
- Se persistir, delete e reinstale

### O app está lento
**Solução**:
- Limpe o cache: Configurações → Safari → Limpar Histórico e Dados
- Reinstale o app

### Não consigo adicionar à tela inicial
**Solução**:
- Certifique-se de estar usando Safari (não Chrome ou Firefox)
- iOS deve ser 11.3 ou superior
- Tente novamente em alguns minutos

### O app não funciona offline
**Solução**:
- Abra o app com internet uma vez
- Service Worker será instalado automaticamente
- Próximas vezes funcionará offline

## Remover o App

1. Toque e segure o ícone do app na tela inicial
2. Toque em **"Remover App"**
3. Toque em **"Remover da Tela Inicial"**

**Nota**: Isso remove apenas o atalho. Para limpar completamente:
- Configurações → Safari → Limpar Histórico e Dados

## Dicas & Truques

### Personalizar o Ícone
1. Toque e segure o ícone
2. Toque em **"Editar"**
3. Você pode adicionar uma foto personalizada

### Criar Atalho de Teclado
1. Configurações → Acessibilidade → Teclado
2. Crie um atalho para abrir o app rapidamente

### Usar Siri
Você pode dizer:
- "Abrir TEG Power"
- "Iniciar TEG Power"

## Diferenças entre App e Navegador

| Recurso | App PWA | Safari |
|---------|---------|--------|
| Ícone na tela inicial | ✅ | ❌ |
| Funciona offline | ✅ | ❌ |
| Tela cheia | ✅ | ❌ |
| Barra de endereço | ❌ | ✅ |
| Compartilhar | ✅ | ✅ |
| Notificações push | ✅ | ❌ |

## Compartilhar com Amigos

### Via iMessage/WhatsApp
1. Copie o link do app
2. Compartilhe com seus amigos
3. Eles podem instalar seguindo este guia

### Via AirDrop
1. Abra o Safari com o app
2. Toque em Compartilhar
3. Escolha um contato para AirDrop

## Suporte Técnico

Se encontrar problemas:

1. **Verifique a conexão de internet**
2. **Atualize o iOS** (Configurações → Geral → Atualização de Software)
3. **Limpe o cache** (Configurações → Safari → Limpar Histórico e Dados)
4. **Reinstale o app** (remova e adicione novamente à tela inicial)

## Recursos Adicionais

- **Documentação PWA**: https://developer.apple.com/library/archive/documentation/AppleApplications/Reference/SafariWebContent/ConfiguringWebApplications/ConfiguringWebApplications.html
- **Web App Manifest**: Especificação W3C para PWAs
- **Service Workers**: Funciona offline e sincroniza dados

---

**Aproveite o jogo! 🎮⚡**

Se tiver dúvidas, consulte este guia ou entre em contato com o desenvolvedor.
