# TEG Power Plant Simulator 🏭⚡

Um **jogo educacional interativo** que simula o funcionamento de uma usina termoelétrica, desenvolvido como trabalho escolar de alto nível sobre Energia Termoelétrica.

## 🎮 Características Principais

- **Simulação Realista**: Ciclo termodinâmico completo (Caldeira → Vapor → Turbina → Gerador → Condensador)
- **Controles Intuitivos**: 3 sliders para gerenciar combustível, vapor e resfriamento
- **Feedback Visual**: Diagrama animado da usina com componentes que "brilham" quando ativos
- **Impacto Ambiental**: Sistema de pontuação que penaliza emissões de CO₂ e consumo de água
- **Eventos Aleatórios**: Falhas simuladas (queda de combustível, vazamento, etc.) para testar capacidade de resposta
- **Ranking de Desempenho**: 4 categorias (Eco Champion, Efficient Operator, Novice Engineer, Needs Training)
- **Responsivo**: Funciona em desktop, tablet e mobile

## 📋 Requisitos

- Navegador moderno (Chrome, Firefox, Safari, Edge)
- Sem dependências externas
- Sem servidor web necessário

## 🚀 Como Usar

### Opção 1: Abrir Localmente
1. Baixe o arquivo `index.html`
2. Clique duas vezes para abrir no navegador
3. Clique em "Iniciar Jogo"

### Opção 2: Servir em Servidor Local
```bash
# Python 3
python -m http.server 8000

# Node.js
npx http-server

# PHP
php -S localhost:8000
```
Depois acesse `http://localhost:8000/index.html`

## 🎯 Objetivo do Jogo

Manter uma usina termoelétrica funcionando de forma **eficiente e ambientalmente responsável** por 5 minutos.

### Controles
- **Combustível (0-100%)**: Aumenta a temperatura da caldeira
- **Vapor (0-100%)**: Abre a válvula para a turbina
- **Resfriamento (0-100%)**: Ativa o condensador

### Métricas Monitoradas
- Temperatura da caldeira (°C)
- Pressão do vapor (bar)
- Rotação da turbina (RPM)
- Potência gerada (MW)
- Eficiência (%)
- Emissões de CO₂ (kg/h)
- Consumo de água (L/h)

## 🏆 Ranking de Desempenho

| Ranking | Eficiência | CO₂ | Descrição |
|---------|-----------|-----|-----------|
| 🏆 Eco Champion | > 80% | < 300 kg | Máximo desempenho ambiental |
| ⭐ Efficient Operator | 60-80% | - | Operação competente |
| 📚 Novice Engineer | 40-60% | - | Iniciante com potencial |
| 🔧 Needs Training | < 40% | - | Requer mais prática |

## 📚 Conceitos Educacionais

### Ciclo Termodinâmico Simplificado (Ciclo Rankine)

```
[1] CALDEIRA
    Combustível queima e aquece água
    Entrada: Combustível (0-100%)
    Saída: Calor (temperatura em °C)
    
    ↓
    
[2] GERADOR DE VAPOR
    Água aquecida vira vapor pressurizado
    Entrada: Calor
    Saída: Vapor (pressão em bar)
    
    ↓
    
[3] TURBINA A VAPOR
    Vapor pressurizado move as pás
    Entrada: Vapor pressurizado
    Saída: Rotação mecânica (RPM)
    
    ↓
    
[4] GERADOR ELÉTRICO
    Rotação induz corrente elétrica
    Entrada: Rotação (RPM)
    Saída: Eletricidade (MW)
    
    ↓
    
[5] CONDENSADOR
    Vapor exaurido é resfriado e reciclado
    Entrada: Vapor exaurido
    Saída: Água líquida (L/h)
    
    ↓
    Retorna à caldeira
```

### Equações Utilizadas

**Temperatura da Caldeira**
```
T = T_anterior + (combustível × 0.8) - (resfriamento × 0.15)
Limites: 20°C a 900°C
```

**Pressão do Vapor**
```
P = 1 + (T / 100) × 2
Limites: 1 bar a 20 bar
```

**Rotação da Turbina**
```
RPM = P × 500 × (abertura_válvula / 100)
Limites: 0 a 3000 RPM
```

**Potência Gerada**
```
P_MW = (RPM / 3000) × 100
Limites: 0 a 100 MW
```

**Eficiência**
```
Eficiência = (P_MW / (combustível × 0.5)) × 100
Limites: 0 a 100%
```

**Emissões de CO₂**
```
CO₂ = combustível × 2 kg/h
```

**Consumo de Água**
```
H₂O = resfriamento × 50 L/h
```

## 🎨 Design & Interface

### Tema Visual
- **Fundo**: Escuro (tema noturno) para reduzir fadiga ocular
- **Cores Primárias**: Laranja (#ff6b35) e Âmbar (#ffa500) para evocar calor
- **Cores de Feedback**:
  - Verde: Operação normal
  - Amarelo: Alerta
  - Vermelho: Crítico

### Componentes Visuais
- Diagrama animado da usina com 5 componentes principais
- Sliders com gradiente de cores (verde → amarelo → vermelho)
- Barra de "Saúde do Planeta" com feedback em tempo real
- Partículas de fumaça que aumentam com emissões de CO₂
- Notificações de eventos e alertas

## 🔧 Estrutura Técnica

### Arquivos
- `index.html` — Arquivo único contendo HTML, CSS e JavaScript
- `DOCUMENTACAO.md` — Documentação técnica completa (4 pilares)
- `README.md` — Este arquivo

### Tecnologias
- **HTML5**: Estrutura semântica
- **CSS3**: Animações, gradientes, media queries
- **JavaScript (Vanilla)**: Sem frameworks, código puro

### Tamanho
- ~50 KB (arquivo único)
- Carregamento instantâneo

## 📊 Dados Técnicos

### Simulação
- **Taxa de atualização**: 60 FPS (requestAnimationFrame)
- **Duração**: 5 minutos (300 segundos)
- **Intervalo de cálculo**: 0.1 segundos

### Eventos Aleatórios
- **Probabilidade**: 5% por segundo
- **Tipos**: Queda de combustível, vazamento de vapor, falha do condensador

### Limites de Segurança
- Temperatura: 20°C a 900°C
- Pressão: 1 bar a 20 bar
- RPM: 0 a 3000
- Potência: 0 a 100 MW

## 🎓 Uso em Sala de Aula

### Disciplinas
- Engenharia Mecânica
- Engenharia Elétrica
- Física (Termodinâmica)
- Educação Ambiental
- Sustentabilidade

### Atividades Sugeridas
1. **Exploração Livre**: Deixar alunos experimentar por 5 minutos
2. **Desafio de Eficiência**: "Quem consegue a maior potência com menor CO₂?"
3. **Análise de Dados**: Coletar resultados de múltiplas sessões e analisar
4. **Discussão**: Comparar estratégias de controle entre alunos
5. **Extensão**: Modificar equações para diferentes tipos de usinas

## 🐛 Troubleshooting

### O jogo não inicia
- Verifique se o navegador suporta ES6 (Chrome 51+, Firefox 54+, Safari 10+)
- Limpe o cache do navegador (Ctrl+Shift+Delete)

### Sliders não respondem
- Verifique se o JavaScript está habilitado
- Tente em outro navegador

### Fumaça não aparece
- Verifique se as emissões de CO₂ estão acima de 10 kg/h
- Aumentar o combustível para gerar mais emissões

## 📝 Notas de Desenvolvimento

### Decisões de Design
1. **Arquivo único**: Facilita distribuição e uso em sala de aula
2. **Sem dependências**: Funciona offline, sem necessidade de CDN
3. **Tema escuro**: Reduz fadiga ocular durante sessões prolongadas
4. **Animações suaves**: Melhoram experiência sem comprometer performance

### Simplificações Pedagógicas
- Equações linearizadas para facilitar compreensão
- Valores ajustados para manter jogo desafiador mas não frustrante
- Eventos aleatórios com probabilidade controlada

### Possíveis Extensões
- Modo multiplayer (competição entre alunos)
- Diferentes tipos de combustível (carvão, gás, biomassa)
- Ciclos termodinâmicos avançados (Brayton, Otto)
- Integração com dados reais de usinas
- Sistema de conquistas/badges

## 📄 Licença

Criado para fins educacionais. Livre para uso em escolas e instituições.

## 👨‍💻 Autor

Desenvolvido como trabalho escolar de alto nível sobre Energia Termoelétrica.

---

**Aproveite o jogo e aprenda sobre energia termoelétrica de forma divertida! ⚡🏭**
